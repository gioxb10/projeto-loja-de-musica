/********************************************************************************
** Form generated from reading UI file 'clientes.ui'
**
** Created by: Qt User Interface Compiler version 5.11.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENTES_H
#define UI_CLIENTES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_clientes
{
public:
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *clientes)
    {
        if (clientes->objectName().isEmpty())
            clientes->setObjectName(QStringLiteral("clientes"));
        clientes->resize(951, 527);
        label = new QLabel(clientes);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(6, 10, 941, 511));
        label->setPixmap(QPixmap(QString::fromUtf8("../../Downloads/press start.png")));
        label->setScaledContents(true);
        label_2 = new QLabel(clientes);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 20, 121, 21));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label_2->setFont(font);

        retranslateUi(clientes);

        QMetaObject::connectSlotsByName(clientes);
    } // setupUi

    void retranslateUi(QDialog *clientes)
    {
        clientes->setWindowTitle(QApplication::translate("clientes", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QApplication::translate("clientes", "Clientes", nullptr));
    } // retranslateUi

};

namespace Ui {
    class clientes: public Ui_clientes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENTES_H
